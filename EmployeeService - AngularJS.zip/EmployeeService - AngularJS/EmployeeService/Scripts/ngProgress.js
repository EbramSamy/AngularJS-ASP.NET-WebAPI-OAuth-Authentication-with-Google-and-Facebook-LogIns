﻿/*
ngprogress 1.1.2 - slim, site-wide progressbar for AngularJS 
(C) 2013 - Victor Bjelkholm 
License: MIT 
Source: https://github.com/VictorBjelkholm/ngProgress 
Date Compiled: 2015-07-27 
*/

/*The MIT License (MIT)

Copyright (c) 2016

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

angular.module("ngProgress.provider", ["ngProgress.directive"]).service("ngProgress", function () {
    "use strict"; return ["$document", "$window", "$compile", "$rootScope", "$timeout", function (a, b, c, d, e) {
        this.autoStyle = !0, this.count = 0, this.height = "10px", this.$scope = d.$new(), this.color = "#0071bc", this.parent = a.find("body")[0], this.count = 0, this.progressbarEl = c("<ng-progress></ng-progress>")(this.$scope), this.parent.appendChild(this.progressbarEl[0]), this.$scope.count = this.count, void 0 !== this.height && this.progressbarEl.eq(0).children().css("height", this.height), void 0 !== this.color && (this.progressbarEl.eq(0).children().css("background-color", this.color), this.progressbarEl.eq(0).children().css("color", this.color)), this.intervalCounterId = 0, this.start = function () { this.show(); var a = this; clearInterval(this.intervalCounterId), this.intervalCounterId = setInterval(function () { isNaN(a.count) ? (clearInterval(a.intervalCounterId), a.count = 0, a.hide()) : (a.remaining = 100 - a.count, a.count = a.count + .15 * Math.pow(1 - Math.sqrt(a.remaining), 2), a.updateCount(a.count)) }, 300) }, this.updateCount = function (a) { this.$scope.count = a, this.$scope.$$phase || this.$scope.$apply() }, this.setHeight = function (a) { return void 0 !== a && (this.height = a, this.$scope.height = this.height, this.$scope.$$phase || this.$scope.$apply()), this.height }, this.setColor = function (a) { return void 0 !== a && (this.color = a, this.$scope.color = this.color, this.$scope.$$phase || this.$scope.$apply()), this.color }, this.hide = function () { this.progressbarEl.children().css("opacity", "0"); var a = this; a.animate(function () { a.progressbarEl.children().css("width", "0%"), a.animate(function () { a.show() }, 500) }, 500) }, this.show = function () { var a = this; a.animate(function () { a.progressbarEl.children().css("opacity", "1") }, 100) }, this.animate = function (a, b) { void 0 !== this.animation && e.cancel(this.animation), this.animation = e(a, b) }, this.status = function () { return this.count }, this.stop = function () { clearInterval(this.intervalCounterId) }, this.set = function (a) { return this.show(), this.updateCount(a), this.count = a, clearInterval(this.intervalCounterId), this.count }, this.css = function (a) { return this.progressbarEl.children().css(a) }, this.reset = function () { return clearInterval(this.intervalCounterId), this.count = 0, this.updateCount(this.count), 0 }, this.complete = function () { this.count = 100, this.updateCount(this.count); var a = this; return clearInterval(this.intervalCounterId), e(function () { a.hide(), e(function () { a.count = 0, a.updateCount(a.count) }, 500) }, 1e3), this.count }, this.setParent = function (a) {

            if (null === a || void 0 === a)
                throw new Error("Provide a valid parent of type HTMLElement");
            null !== this.parent && void 0 !== this.parent && this.parent.removeChild(this.progressbarEl[0]), this.parent = a, this.parent.appendChild(this.progressbarEl[0])
        }, this.getDomElement = function () { return this.progressbarEl }, this.setAbsolute = function () { this.progressbarEl.css("position", "absolute") }
    }]
}).factory("ngProgressFactory", ["$injector", "ngProgress", function (a, b) { var c = { createInstance: function () { return a.instantiate(b) } }; return c }]), angular.module("ngProgress.directive", []).directive("ngProgress", ["$window", "$rootScope", function (a, b) { var c = { replace: !0, restrict: "E", link: function (a, b, c, d) { a.$watch("count", function (c) { (void 0 !== c || null !== c) && (a.counter = c, b.eq(0).children().css("width", c + "%")) }), a.$watch("color", function (c) { (void 0 !== c || null !== c) && (a.color = c, b.eq(0).children().css("background-color", c), b.eq(0).children().css("color", c)) }), a.$watch("height", function (c) { (void 0 !== c || null !== c) && (a.height = c, b.eq(0).children().css("height", c)) }) }, template: '<div id="ngProgress-container"><div id="ngProgress"></div></div>' }; return c }]), angular.module("ngProgress", ["ngProgress.directive", "ngProgress.provider"]);