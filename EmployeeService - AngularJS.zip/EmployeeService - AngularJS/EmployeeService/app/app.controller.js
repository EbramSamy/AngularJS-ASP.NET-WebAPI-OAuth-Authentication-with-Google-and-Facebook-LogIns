﻿(function () {

	// Registering a controller as a named function (instead of anonymous function)
    angular
        .module('EmployeeApp')
        .controller('EmployeeController', ['$rootScope', '$scope', '$state', 'EmployeeService', EmployeeController]);

    function EmployeeController($rootScope, $scope, $state, EmployeeService) {
      
        var self = this;

        // Function to check if a user authenticated through FB or Google is registered in our local DB
        self.signupExternalUser = function () {
            EmployeeService.signupExternalUser(self.accessToken, self.loginProvider)
            .success(function (response) {
                window.location = "/api/Account/ExternalLogin?provider=" + self.loginProvider + "&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A53907%2Fapp%2Findex.html&state=zF1ONOVm-aHsg1UIroIE57ZyFgxZkXJXExroH3dH20s1";
            })
            .error(function (err) {
                DisplayErrorMessage(err);
            });
        }

        // Function to register a user authenticated through FB or Google in our local DB
        self.isUserRegistered = function () {
            EmployeeService.isUserRegistered(self.accessToken)
            .success(function (response) {
                self.loginProvider = response.LoginProvider;
                if (response.HasRegistered) {
                    // Store the access-token and username to browser's local storage if the user is already registered 
                    localStorage.setItem("accessToken", self.accessToken);
                    localStorage.setItem("loggedInUser", response.Email);
                    // Route the user to the Protected Page of the application (Employee Data)
                    $state.go('dataPage');
                }
                else {
                    // Register the user in our local DB otherwise
                    self.signupExternalUser();
                }
            })
            .error(function (err) {
                DisplayErrorMessage(err);
            });
        }

        // Fuction to retrieve the access-token from the URI
        self.getAccessToken = function() {
            if (location.hash) {
                if (location.hash.split('access_token=')) {
                    self.accessToken = location.hash.split('access_token=')[1].split('&')[0];
                    if (self.accessToken) {
                        self.isUserRegistered();
                    }
                }
            }
        }
        self.getAccessToken();    

    };

})();