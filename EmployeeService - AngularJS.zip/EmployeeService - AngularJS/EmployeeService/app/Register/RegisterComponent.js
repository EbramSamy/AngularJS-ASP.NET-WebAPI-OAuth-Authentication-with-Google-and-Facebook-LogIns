﻿(function () {

    // Registering a controller as a named function (instead of anonymous function)
    angular
        .module('EmployeeApp')
        .component('registerUser', {
            bindings: {

            },
            templateUrl: 'Register/RegisterTemplate.html',
            controller: function (registerService, $stateParams, $state) {
                var self = this;

                // Function to redirect the user to the LogIn page
                self.redirectToLogInPage = function () {
                    $state.go('login');
                }

                // Function to register a user
                self.registerUser = function () {

                    if (self.user == undefined || self.user == null) {
                        DisplayErrorMessage("All fields are mandatory !");
                    }
                        // Form Validations
                    else {
                        if (self.user.email == null || self.user.email == undefined || self.user.email == "" || self.user.password == null || self.user.password == undefined || self.user.password == "" || self.user.confirmPassword == null || self.user.confirmPassword == undefined || self.user.confirmPassword == "") {
                            DisplayErrorMessage("All fields are mandatory !");
                        }
                        else if (self.user.password != self.user.confirmPassword) {
                            DisplayErrorMessage("Passwords don't match !");
                        }
                            // Register the user
                        else {
                            registerService.registerUser(self.user)
                            .success(function (response) {
                                DisplaySuccessMessage("Registration Successful !");
                            })
                            .error(function (err) {
                                DisplayErrorMessage((err.ModelState.err[1]));
                            });
                        }
                    }
                }
            }
        })

})();