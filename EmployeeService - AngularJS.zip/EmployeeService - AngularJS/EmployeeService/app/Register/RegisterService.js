﻿(function () {

    angular
        .module('EmployeeApp')
        .factory('registerService', function ($http) {

            var service = {
                registerUser: registerUser
            };

            return service;

            // Function to register a user
            function registerUser(user) {
                return $http({
                    method: 'POST',
                    url: 'http://localhost:53907/api/account/register',
                    data: {
                        email: user.email,
                        password: user.password,
                        confirmPassword: user.confirmPassword
                    }
                });
            }
           
        });

})();
