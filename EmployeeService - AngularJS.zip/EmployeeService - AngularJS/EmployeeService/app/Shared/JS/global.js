﻿// Function to display any success message
function DisplaySuccessMessage(message) {
    $('#successPopUp').modal();
    $('#successMsg').text(message);
    $('.modal-body .alloverbtnactive').attr("tabindex", "0").focus();
}

// Function to display any error message
function DisplayErrorMessage(message) {
    $('#errorPopUp').modal({ show: true });
    $('#errorMSG').text(message);
    $('.modal-body .alloverbtnactive').attr("tabindex", "0").focus();
}