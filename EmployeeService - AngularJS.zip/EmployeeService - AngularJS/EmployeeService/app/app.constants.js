﻿(function () {
    //This file contains all the Web-Api constants
    angular
        .module('EmployeeApp')
        .constant('apiurls', {
            apiDomain: ''            
        })

})();