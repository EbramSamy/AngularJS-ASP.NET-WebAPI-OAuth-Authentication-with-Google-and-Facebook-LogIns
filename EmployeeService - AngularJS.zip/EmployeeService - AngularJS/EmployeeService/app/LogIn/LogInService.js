﻿(function () {

    angular
        .module('EmployeeApp')
        .factory('logInService', function ($http) {

            var service = {
                logInUser: logInUser
            };

            return service;

            // Function to sign in a user
            function logInUser(user) {             
                return $http({
                    method: 'POST',
                    url: 'http://localhost:53907/token',
                    data: $.param({ username: user.username, password: user.password, grant_type:"password" }),
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                });
            }

        });

})();
