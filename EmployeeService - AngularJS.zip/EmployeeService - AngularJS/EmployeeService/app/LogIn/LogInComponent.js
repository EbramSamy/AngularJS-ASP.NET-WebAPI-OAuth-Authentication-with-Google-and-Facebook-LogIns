﻿(function () {

    // Registering a controller as a named function (instead of anonymous function)
    angular
        .module('EmployeeApp')
        .component('logIn', {
            bindings: {

            },
            templateUrl: 'LogIn/LogInTemplate.html',
            controller: function (logInService, $stateParams, $state) {
                var self = this;

                // Function to redirect the user to the Register page
                self.redirectToRegisterPage = function () {
                    $state.go('register');
                }

                // Google LogIn Function
                self.googleLogIn = function () {
                    window.location = "/api/Account/ExternalLogin?provider=Google&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A53907%2Fapp%2Findex.html&state=zF1ONOVm-aHsg1UIroIE57ZyFgxZkXJXExroH3dH20s1"
                }

                // Facebook Log In Function
                self.facebookLogIn = function () {
                    window.location = "/api/Account/ExternalLogin?provider=Facebook&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A53907%2Fapp%2Findex.html&state=zF1ONOVm-aHsg1UIroIE57ZyFgxZkXJXExroH3dH20s1"
                }

                // Log-In Function
                self.logInUser = function () {
                    var un = self.user.username;
                    var pw = self.user.password;

                    // Form Validations
                    if (un == null || un == undefined || un == "" || pw == null || pw == undefined || pw == "") {
                     DisplayErrorMessage("Username and Password are mandatory");                       
                    }
                    // Log-In
                    else {
                        logInService.logInUser(self.user)
                        .success(function (response) {
                            localStorage.setItem("accessToken", response.access_token);
                            // Set the userName of the authenticated user
                            localStorage.setItem("loggedInUser", response.userName);
                            // Route to GetData page
                            $state.go('dataPage');
                        })
                        .error(function (error) {
                            DisplayErrorMessage(JSON.stringify(error.error_description));
                        });
                    }
                }
            }
        })
})();