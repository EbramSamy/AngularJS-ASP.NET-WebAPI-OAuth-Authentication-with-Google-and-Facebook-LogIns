﻿(function () {

    angular
        .module('EmployeeApp')
        .factory('getDataService', function ($http) {

            var service = {
                loadEmployees: loadEmployees
            };

            return service;

            // Function to register a user
            function loadEmployees(user) {
                return $http({
                    method: 'GET',
                    url: 'http://localhost:53907/api/employees',
                    headers: { // Pass the token along with your request
                        'Authorization': 'Bearer '
                            + localStorage.getItem("accessToken")
                    }
                });
            }

        });

})();
