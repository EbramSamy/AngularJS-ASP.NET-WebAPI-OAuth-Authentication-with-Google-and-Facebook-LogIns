﻿(function () {

    // Registering a controller as a named function (instead of anonymous function)
    angular
        .module('EmployeeApp')
        .component('getData', {
            bindings: {

            },
            templateUrl: 'GetData/GetDataTemplate.html',
            controller: function (getDataService, $stateParams, $state) {
                var self = this;
                self.showTable = false; // Hide the table initially

                // Route to Log In page if there is no access-token present
                if (localStorage.getItem('accessToken') == null) {
                    $state.go('login');
                }

                // Get the logged in username
                self.userName = 'Hello ' + localStorage.getItem('loggedInUser');

                // Log-Out Function
                // Deletes the access-token and username from the browser's local storage
                // And redirects the user to Log In page
                self.logOff = function () {
                    localStorage.removeItem('accessToken');
                    localStorage.removeItem('loggedInUser');
                    $state.go('login');
                }

                // Function to load employees
                self.loadEmployees = function () {
                    getDataService.loadEmployees()
                    .success(function (response) {
                        self.showTable = true;
                        self.employeeList = response;
                    })
                    .error(function (error) {
                        DisplayErrorMessage(JSON.stringify(error.error));
                    });
                }
            }
        })
})();