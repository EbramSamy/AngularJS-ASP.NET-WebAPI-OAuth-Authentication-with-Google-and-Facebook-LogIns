﻿(function () {
    angular
        .module('EmployeeApp')
        .factory('EmployeeService', ['$http', 'apiurls', EmployeeService]);

    function EmployeeService($http, apiurls) {
        var service = {
            isUserRegistered: isUserRegistered,
            signupExternalUser: signupExternalUser
        };
      
        return service;

        // Function to check if a user authenticated through FB or Google is registered in our local DB
        function isUserRegistered(accessToken) {
            return $http({
                method: 'GET',
                url: 'http://localhost:53907/api/Account/UserInfo',
                headers: {
                    'content-type': 'application/json',
                    'Authorization': 'Bearer ' + accessToken
                },
            });
        }

        // Function to register a user authenticated through FB or Google in our local DB
        function signupExternalUser(accessToken) {
            return $http({
                method: 'POST',
                url: 'http://localhost:53907/api/Account/RegisterExternal',
                headers: {
                    'content-type': 'application/json',
                    'Authorization': 'Bearer ' + accessToken
                }
            });
        }
    };

})();