﻿/// <reference path="components/Contact/contact.html" />
(function () {
    //Using ui-router instead of ngRouter
    angular
        .module('EmployeeApp')
        .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', EmployeeRoute]);

    function EmployeeRoute($stateProvider, $urlRouterProvider, $locationProvider) {
        $urlRouterProvider.otherwise('/');

        $stateProvider
            .state('login', {
                url: '/LogIn',
                template: '<log-in></log-in>'
            })
            .state('register', {
                url: '/Register',
                template: '<register-user></register-user>'
            })
            .state('dataPage', {
                url: '/Content',
                template: '<get-data></get-data>'
            });
       
    }
})();