﻿//Code to make the LogIn state as the default state
var app = angular.module('EmployeeApp')
.run(['$state', function ($state) {
    $state.transitionTo('login');
}])
